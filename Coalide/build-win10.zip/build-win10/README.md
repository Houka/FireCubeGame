# CUGL Demos (Windows Platforms)

This directory contains the Visual Studio project for for building and installing the 
the basic demo on Windows 10. This demo draws the logo and moves it about the screen. 
It also has a button to quit the application at the bottom of the screen.